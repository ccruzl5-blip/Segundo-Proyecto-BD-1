from database.conexion import obtener_conexion

def registrar_empleado(nombre, apellido, departamento, correo):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = "INSERT INTO Empleados (nombre, apellido, departamento, correo) VALUES (?, ?, ?, ?)"
        cursor.execute(sql, (nombre, apellido, departamento, correo))
        conn.commit()
        print(f"Empleado '{nombre} {apellido}' registrado con éxito.")
    except Exception as e:
        print(f"Error al registrar empleado: {e}")
    finally:
        conn.close()

def actualizar_empleado(id_empleado, nuevo_departamento, nuevo_correo):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = "UPDATE Empleados SET departamento = ?, correo = ? WHERE id_empleado = ?"
        cursor.execute(sql, (nuevo_departamento, nuevo_correo, id_empleado))
        conn.commit()
        print(f"Empleado ID {id_empleado} actualizado.")
    except Exception as e:
        print(f"Error al actualizar empleado: {e}")
    finally:
        conn.close()

def eliminar_empleado(id_empleado):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        # Se cumplirá la Integridad Referencial si el empleado tiene solicitudes asociadas
        sql = "DELETE FROM Empleados WHERE id_empleado = ?"
        cursor.execute(sql, (id_empleado,))
        conn.commit()
        print(f"Empleado ID {id_empleado} eliminado correctamente.")
    except Exception as e:
        print(f"No se puede eliminar el empleado (Regla de Integridad): {e}")
    finally:
        conn.close()