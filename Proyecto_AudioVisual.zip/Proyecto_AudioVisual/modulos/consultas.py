from database.conexion import obtener_conexion

def mostrar_todos_los_empleados():
    conn = obtener_conexion()
    if not conn:
        raise Exception("No hay conexión con SQL Server")
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id_empleado, nombre, apellido, departamento, correo FROM Empleados")
        return [tuple(row) for row in cursor.fetchall()]
    finally:
        conn.close()

def mostrar_todos_los_equipos():
    conn = obtener_conexion()
    if not conn:
        raise Exception("No hay conexión con SQL Server")
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.id_equipo, e.nombre, e.marca, e.modelo, e.estado, c.nombre 
            FROM Equipos e
            INNER JOIN Categorias c ON e.id_categoria = c.id_categoria
        """)
        return [tuple(row) for row in cursor.fetchall()]
    finally:
        conn.close()

def mostrar_equipos_disponibles():
    conn = obtener_conexion()
    if not conn:
        raise Exception("No hay conexión con SQL Server")
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.id_equipo, e.nombre, e.marca, e.modelo, c.nombre 
            FROM Equipos e
            INNER JOIN Categorias c ON e.id_categoria = c.id_categoria
            WHERE e.estado = 'Disponible'
        """)
        return [tuple(row) for row in cursor.fetchall()]
    finally:
        conn.close()

def mostrar_solicitudes_registradas():
    conn = obtener_conexion()
    if not conn:
        raise Exception("No hay conexión con SQL Server")
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.id_solicitud, s.fecha_solicitud, s.fecha_uso, s.fecha_devolucion_prevista, 
                   s.estado, e.nombre + ' ' + e.apellido AS Empleado
            FROM Solicitudes s
            INNER JOIN Empleados e ON s.id_empleado = e.id_empleado
        """)
        return [tuple(row) for row in cursor.fetchall()]
    finally:
        conn.close()