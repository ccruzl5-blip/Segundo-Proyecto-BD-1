from database.conexion import obtener_conexion

def registrar_solicitud_maestro_detalle(id_empleado, fecha_uso, fecha_devolucion, motivo, lista_id_equipos):
    conn = obtener_conexion()
    if not conn: 
        print("Error: No hay conexión a la base de datos.")
        return False
        
    cursor = conn.cursor()
    try:
        # 1. Insertar Registro Maestro
        sql_maestro = """
            INSERT INTO Solicitudes (fecha_uso, fecha_devolucion_prevista, motivo, estado, id_empleado)
            OUTPUT INSERTED.id_solicitud
            VALUES (?, ?, ?, 'Pendiente', ?)
        """
        cursor.execute(sql_maestro, (fecha_uso, fecha_devolucion, motivo, id_empleado))
        id_solicitud = cursor.fetchone()[0]

        # 2. Insertar Registros de Detalle y actualizar estado de Equipos
        for id_equipo in lista_id_equipos:
            sql_detalle = "INSERT INTO Detalle_Solicitudes (id_solicitud, id_equipo) VALUES (?, ?)"
            cursor.execute(sql_detalle, (id_solicitud, id_equipo))

            sql_actualizar_equipo = "UPDATE Equipos SET estado = 'Prestado' WHERE id_equipo = ?"
            cursor.execute(sql_actualizar_equipo, (id_equipo,))

        # Confirmar la transacción en SQL Server
        conn.commit()
        print(f"Solicitud ID {id_solicitud} guardada correctamente en SQL Server.")
        return True

    except Exception as e:
        conn.rollback()
        # Muestra en la terminal el error exacto de SQL Server
        print(f"ERROR EN TRANSACCIÓN SQL: {e}")
        raise e  # Lanza el error para que la ventana de la App muestre el mensaje descriptivo
    finally:
        conn.close()

def cambiar_estado_solicitud(id_solicitud, nuevo_estado):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = "UPDATE Solicitudes SET estado = ? WHERE id_solicitud = ?"
        cursor.execute(sql, (nuevo_estado, id_solicitud))
        conn.commit()
    finally:
        conn.close()