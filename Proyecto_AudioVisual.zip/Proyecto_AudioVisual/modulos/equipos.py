from database.conexion import obtener_conexion

def registrar_equipo(nombre, marca, modelo, numero_serie, id_categoria):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = """
            INSERT INTO Equipos (nombre, marca, modelo, numero_serie, estado, id_categoria)
            VALUES (?, ?, ?, ?, 'Disponible', ?)
        """
        cursor.execute(sql, (nombre, marca, modelo, numero_serie, id_categoria))
        conn.commit()
        print(f"Equipo '{nombre}' registrado correctamente.")
    except Exception as e:
        print(f"Error al registrar equipo: {e}")
    finally:
        conn.close()

def actualizar_estado_equipo(id_equipo, nuevo_estado):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = "UPDATE Equipos SET estado = ? WHERE id_equipo = ?"
        cursor.execute(sql, (nuevo_estado, id_equipo))
        conn.commit()
        print(f"Estado del equipo ID {id_equipo} cambiado a '{nuevo_estado}'.")
    except Exception as e:
        print(f"Error al actualizar estado del equipo: {e}")
    finally:
        conn.close()

def eliminar_equipo(id_equipo):
    conn = obtener_conexion()
    if not conn: return
    cursor = conn.cursor()
    try:
        sql = "DELETE FROM Equipos WHERE id_equipo = ?"
        cursor.execute(sql, (id_equipo,))
        conn.commit()
        print(f"Equipo ID {id_equipo} eliminado correctamente.")
    except Exception as e:
        print(f"No se puede eliminar el equipo (Regla de Integridad): {e}")
    finally:
        conn.close()
        