USE GestionAudiovisual;
GO


SELECT * FROM Empleados;

IF NOT EXISTS (SELECT * FROM Empleados)
BEGIN
    INSERT INTO Empleados (nombre, apellido, departamento, correo) VALUES
    ('Juan', 'Pérez', 'Sistemas', 'juan.perez@empresa.com'),
    ('María', 'Gómez', 'Recursos Humanos', 'maria.gomez@empresa.com'),
    ('Carlos', 'López', 'Marketing', 'carlos.lopez@empresa.com');
END
GO