CREATE DATABASE GestionAudiovisual;
GO

USE GestionAudiovisual;
GO


CREATE TABLE Categorias (
    id_categoria INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);


CREATE TABLE Empleados (
    id_empleado INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE
);


CREATE TABLE Equipos (
    id_equipo INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    numero_serie VARCHAR(50) NOT NULL UNIQUE,
    estado VARCHAR(20) NOT NULL DEFAULT 'Disponible' 
        CHECK (estado IN ('Disponible', 'Prestado', 'En Mantenimiento', 'Inactivo')),
    id_categoria INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES Categorias(id_categoria)
);


CREATE TABLE Solicitudes (
    id_solicitud INT IDENTITY(1,1) PRIMARY KEY,
    fecha_solicitud DATETIME DEFAULT GETDATE(),
    fecha_uso DATE NOT NULL,
    fecha_devolucion_prevista DATE NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'Pendiente' 
        CHECK (estado IN ('Pendiente', 'Aprobada', 'Completada', 'Cancelada')),
    id_empleado INT NOT NULL,
    FOREIGN KEY (id_empleado) REFERENCES Empleados(id_empleado),
    CONSTRAINT CK_Fechas CHECK (fecha_devolucion_prevista >= fecha_uso)
);


CREATE TABLE Detalle_Solicitudes (
    id_detalle INT IDENTITY(1,1) PRIMARY KEY,
    id_solicitud INT NOT NULL,
    id_equipo INT NOT NULL,
    FOREIGN KEY (id_solicitud) REFERENCES Solicitudes(id_solicitud) ON DELETE CASCADE,
    FOREIGN KEY (id_equipo) REFERENCES Equipos(id_equipo),
    CONSTRAINT UQ_Solicitud_Equipo UNIQUE (id_solicitud, id_equipo)
);




INSERT INTO Categorias (nombre) VALUES ('Audio'), ('Video'), ('Computación'), ('Accesorios');


INSERT INTO Empleados (nombre, apellido, departamento, correo) VALUES
('Juan', 'Pérez', 'Sistemas', 'juan.perez@empresa.com'),
('María', 'Gómez', 'Recursos Humanos', 'maria.gomez@empresa.com'),
('Carlos', 'López', 'Marketing', 'carlos.lopez@empresa.com'),
('Ana', 'Martínez', 'Finanzas', 'ana.martinez@empresa.com'),
('Luis', 'Rodríguez', 'Operaciones', 'luis.rodriguez@empresa.com');


INSERT INTO Equipos (nombre, marca, modelo, numero_serie, estado, id_categoria) VALUES
('Microfono Inalambrico', 'Shure', 'SM58', 'SN-001', 'Disponible', 1),
('Bocina Portatil', 'JBL', 'EON610', 'SN-002', 'Disponible', 1),
('Consola de Audio', 'Yamaha', 'MG10XU', 'SN-003', 'Disponible', 1),
('Proyector HD', 'Epson', 'PowerLite', 'SN-004', 'Disponible', 2),
('Camara 4K', 'Sony', 'Alpha 7', 'SN-005', 'Disponible', 2),
('Pantalla Proyeccion', 'Elite', 'T100U', 'SN-006', 'Disponible', 2),
('Laptop Dell XPS', 'Dell', 'XPS 15', 'SN-007', 'Disponible', 3),
('Laptop HP ProBook', 'HP', '450 G8', 'SN-008', 'Disponible', 3),
('MacBook Pro', 'Apple', 'M1 13', 'SN-009', 'Disponible', 3),
('Tripode de Aluminio', 'Manfrotto', 'MT055', 'SN-010', 'Disponible', 4),
('Cable HDMI 10m', 'Generic', 'HDMI-10', 'SN-011', 'Disponible', 4),
('Adaptador USB-C', 'Anker', 'A8380', 'SN-012', 'Disponible', 4),
('Puntero Laser', 'Logitech', 'R400', 'SN-013', 'Disponible', 4),
('Camara Web Full HD', 'Logitech', 'C920', 'SN-014', 'Disponible', 2),
('Bocina de Conferencia', 'Jabra', 'Speak 510', 'SN-015', 'Disponible', 1);

select * from Empleados 