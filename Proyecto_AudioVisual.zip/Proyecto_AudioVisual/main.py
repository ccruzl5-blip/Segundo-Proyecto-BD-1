import customtkinter as ctk
from tkinter import ttk, messagebox
from database.conexion import obtener_conexion
from modulos.consultas import (
    mostrar_todos_los_empleados,
    mostrar_todos_los_equipos,
    mostrar_equipos_disponibles,
    mostrar_solicitudes_registradas
)
from modulos.empleados import registrar_empleado, eliminar_empleado
from modulos.equipos import registrar_equipo
from modulos.solicitudes import registrar_solicitud_maestro_detalle, cambiar_estado_solicitud

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class AppEscritorio(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Sistema de Gestión de Audiovisual")
        self.geometry("1000x650")
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Panel Lateral
        self.frame_nav = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.frame_nav.grid(row=0, column=0, sticky="nsew")

        ctk.CTkLabel(self.frame_nav, text="AUDIOVISUALES", font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, padx=20, pady=20)
        ctk.CTkButton(self.frame_nav, text="Consultas y Tablas", command=self.mostrar_pestana_consultas).grid(row=1, column=0, padx=20, pady=10)
        ctk.CTkButton(self.frame_nav, text="Nueva Solicitud", command=self.mostrar_pestana_solicitud).grid(row=2, column=0, padx=20, pady=10)
        ctk.CTkButton(self.frame_nav, text="Registrar Empleado", command=self.mostrar_pestana_empleados).grid(row=3, column=0, padx=20, pady=10)
        ctk.CTkButton(self.frame_nav, text="Registrar Equipo", command=self.mostrar_pestana_equipos).grid(row=4, column=0, padx=20, pady=10)
        ctk.CTkButton(self.frame_nav, text="Gestionar / Eliminar", command=self.mostrar_pestana_gestion).grid(row=5, column=0, padx=20, pady=10)

        # Contenedor Principal
        self.frame_contenido = ctk.CTkFrame(self, corner_radius=10)
        self.frame_contenido.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

        self.mostrar_pestana_consultas()

    def limpiar_contenido(self):
        for widget in self.frame_contenido.winfo_children():
            widget.destroy()

    # -------------------------------------------------------------
    # PESTAÑA 1: CONSULTAS (CORREGIDO PARA MOSTRAR FILAS)
    # -------------------------------------------------------------
    def mostrar_pestana_consultas(self):
        self.limpiar_contenido()
        frame = ctk.CTkFrame(self.frame_contenido)
        frame.pack(fill="both", expand=True, padx=15, pady=15)

        ctk.CTkLabel(frame, text="Consultas del Sistema", font=ctk.CTkFont(size=20, weight="bold")).pack(pady=10)

        f_botones = ctk.CTkFrame(frame)
        f_botones.pack(fill="x", pady=5)

        ctk.CTkButton(f_botones, text="Empleados", command=self.cargar_empleados).pack(side="left", padx=5)
        ctk.CTkButton(f_botones, text="Equipos", command=self.cargar_equipos).pack(side="left", padx=5)
        ctk.CTkButton(f_botones, text="Equipos Disponibles", command=self.cargar_equipos_disponibles).pack(side="left", padx=5)
        ctk.CTkButton(f_botones, text="Solicitudes", command=self.cargar_solicitudes).pack(side="left", padx=5)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", rowheight=25, font=('Calibri', 10))

        # Recrear tabla limpia
        self.tabla = ttk.Treeview(frame, show="headings")
        self.tabla.pack(fill="both", expand=True, pady=10)

    def popular_tabla(self, columnas, datos):
        self.tabla.delete(*self.tabla.get_children())
        self.tabla["columns"] = columnas
        for col in columnas:
            self.tabla.heading(col, text=col)
            self.tabla.column(col, width=120, anchor="center")
        for fila in datos:
            self.tabla.insert("", "end", values=fila)

    def cargar_empleados(self):
        try:
            datos = mostrar_todos_los_empleados()
            self.popular_tabla(("ID", "Nombre", "Apellido", "Departamento", "Correo"), datos)
        except Exception as e:
            messagebox.showerror("Error SQL", f"No se pudo cargar Empleados: {e}")

    def cargar_equipos(self):
        try:
            datos = mostrar_todos_los_equipos()
            self.popular_tabla(("ID", "Nombre", "Marca", "Modelo", "Estado", "Categoría"), datos)
        except Exception as e:
            messagebox.showerror("Error SQL", f"No se pudo cargar Equipos: {e}")

    def cargar_equipos_disponibles(self):
        try:
            datos = mostrar_equipos_disponibles()
            self.popular_tabla(("ID", "Nombre", "Marca", "Modelo", "Categoría"), datos)
        except Exception as e:
            messagebox.showerror("Error SQL", f"No se pudo cargar Equipos Disponibles: {e}")

    def cargar_solicitudes(self):
        try:
            datos = mostrar_solicitudes_registradas()
            filas_formateadas = [(f[0], str(f[1])[:10], str(f[2]), str(f[3]), f[4], f[5]) for f in datos]
            self.popular_tabla(("ID", "Fecha Solicitud", "Fecha Uso", "Fecha Dev", "Estado", "Empleado"), filas_formateadas)
        except Exception as e:
            messagebox.showerror("Error SQL", f"No se pudo cargar Solicitudes: {e}")

    # -------------------------------------------------------------
    # PESTAÑA 2: NUEVA SOLICITUD
    # -------------------------------------------------------------
    def mostrar_pestana_solicitud(self):
        self.limpiar_contenido()

        frame = ctk.CTkFrame(self.frame_contenido)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(frame, text="Nueva Solicitud de Préstamo (Maestro-Detalle)", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)

        self.dict_empleados = {}
        opciones_combobox = []
        
        conn = obtener_conexion()
        if conn:
            try:
                cur = conn.cursor()
                cur.execute("SELECT id_empleado, nombre, apellido, departamento FROM Empleados")
                filas = cur.fetchall()
                conn.close()
                for e in filas:
                    label = f"{e[0]} - {e[1]} {e[2]} ({e[3]})"
                    self.dict_empleados[label] = e[0]
                    opciones_combobox.append(label)
            except Exception as ex:
                messagebox.showerror("Error SQL", f"Fallo al consultar Empleados: {ex}")

        if not opciones_combobox:
            opciones_combobox = ["No hay empleados registrados"]

        ctk.CTkLabel(frame, text="Seleccione Empleado:").pack(anchor="w", padx=20, pady=(5,0))
        self.cb_empleado = ctk.CTkComboBox(frame, width=380, values=opciones_combobox)
        self.cb_empleado.pack(padx=20, pady=5)
        self.cb_empleado.set(opciones_combobox[0])

        ctk.CTkLabel(frame, text="Fecha Uso (AAAA-MM-DD):").pack(anchor="w", padx=20, pady=(5,0))
        txt_fuso = ctk.CTkEntry(frame, width=380, placeholder_text="2026-10-10")
        txt_fuso.pack(padx=20, pady=5)

        ctk.CTkLabel(frame, text="Fecha Dev (AAAA-MM-DD):").pack(anchor="w", padx=20, pady=(5,0))
        txt_fdev = ctk.CTkEntry(frame, width=380, placeholder_text="2026-10-12")
        txt_fdev.pack(padx=20, pady=5)

        ctk.CTkLabel(frame, text="Motivo:").pack(anchor="w", padx=20, pady=(5,0))
        txt_mot = ctk.CTkEntry(frame, width=380, placeholder_text="Reunión Trabajo")
        txt_mot.pack(padx=20, pady=5)

        ctk.CTkLabel(frame, text="IDs Equipos Solicitados (ej. 1,2):").pack(anchor="w", padx=20, pady=(5,0))
        txt_eq = ctk.CTkEntry(frame, width=380, placeholder_text="1,2")
        txt_eq.pack(padx=20, pady=5)

        def guardar():
            emp_sel = self.cb_empleado.get()
            if not self.dict_empleados or emp_sel not in self.dict_empleados:
                messagebox.showerror("Error", "Seleccione un empleado válido.")
                return

            id_emp = self.dict_empleados[emp_sel]
            f_uso = txt_fuso.get().strip()
            f_dev = txt_fdev.get().strip()
            motivo = txt_mot.get().strip()
            raw_eq = txt_eq.get().strip()

            if not f_uso or not f_dev or not motivo or not raw_eq:
                messagebox.showwarning("Atención", "Complete todos los campos.")
                return

            try:
                lista_eq = [int(x.strip()) for x in raw_eq.split(',') if x.strip()]
                exito = registrar_solicitud_maestro_detalle(id_emp, f_uso, f_dev, motivo, lista_eq)
                if exito:
                    messagebox.showinfo("Éxito", "Solicitud registrada correctamente.")
                    self.mostrar_pestana_solicitud()
            except Exception as e:
                messagebox.showerror("Error", f"Fallo al registrar: {e}")

        ctk.CTkButton(frame, text="Guardar Solicitud", command=guardar, fg_color="green", hover_color="darkgreen").pack(pady=15)

    # -------------------------------------------------------------
    # PESTAÑA 3: EMPLEADOS
    # -------------------------------------------------------------
    def mostrar_pestana_empleados(self):
        self.limpiar_contenido()
        frame = ctk.CTkFrame(self.frame_contenido)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(frame, text="Registrar Nuevo Empleado", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)
        txt_nom = ctk.CTkEntry(frame, placeholder_text="Nombre", width=300); txt_nom.pack(pady=5)
        txt_ape = ctk.CTkEntry(frame, placeholder_text="Apellido", width=300); txt_ape.pack(pady=5)
        txt_dep = ctk.CTkEntry(frame, placeholder_text="Departamento", width=300); txt_dep.pack(pady=5)
        txt_cor = ctk.CTkEntry(frame, placeholder_text="Correo Electrónico", width=300); txt_cor.pack(pady=5)

        def guardar():
            if txt_nom.get() and txt_ape.get() and txt_dep.get() and txt_cor.get():
                registrar_empleado(txt_nom.get(), txt_ape.get(), txt_dep.get(), txt_cor.get())
                messagebox.showinfo("Éxito", "Empleado registrado con éxito.")
                self.mostrar_pestana_empleados()
            else:
                messagebox.showwarning("Atención", "Complete todos los campos.")

        ctk.CTkButton(frame, text="Guardar Empleado", command=guardar).pack(pady=10)

    # -------------------------------------------------------------
    # PESTAÑA 4: EQUIPOS
    # -------------------------------------------------------------
    def mostrar_pestana_equipos(self):
        self.limpiar_contenido()
        frame = ctk.CTkFrame(self.frame_contenido)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(frame, text="Registrar Nuevo Equipo Audiovisual", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)
        txt_nom = ctk.CTkEntry(frame, placeholder_text="Nombre del equipo", width=300); txt_nom.pack(pady=5)
        txt_mar = ctk.CTkEntry(frame, placeholder_text="Marca", width=300); txt_mar.pack(pady=5)
        txt_mod = ctk.CTkEntry(frame, placeholder_text="Modelo", width=300); txt_mod.pack(pady=5)
        txt_ser = ctk.CTkEntry(frame, placeholder_text="Número de Serie", width=300); txt_ser.pack(pady=5)
        cb_cat = ctk.CTkComboBox(frame, values=["1 - Audio", "2 - Video", "3 - Computación", "4 - Accesorios"], width=300); cb_cat.pack(pady=5)

        def guardar():
            if txt_nom.get() and txt_ser.get():
                id_cat = int(cb_cat.get().split(" - ")[0])
                registrar_equipo(txt_nom.get(), txt_mar.get(), txt_mod.get(), txt_ser.get(), id_cat)
                messagebox.showinfo("Éxito", "Equipo guardado.")
                self.mostrar_pestana_equipos()

        ctk.CTkButton(frame, text="Guardar Equipo", command=guardar).pack(pady=10)

    # -------------------------------------------------------------
    # PESTAÑA 5: GESTIÓN
    # -------------------------------------------------------------
    def mostrar_pestana_gestion(self):
        self.limpiar_contenido()
        frame = ctk.CTkFrame(self.frame_contenido)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(frame, text="Gestión de Estados y Bajas", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=10)

        f1 = ctk.CTkFrame(frame); f1.pack(fill="x", pady=10, padx=10)
        ctk.CTkLabel(f1, text="Estado Solicitud:").pack(side="left", padx=5)
        txt_sol_id = ctk.CTkEntry(f1, placeholder_text="ID Solicitud", width=100); txt_sol_id.pack(side="left", padx=5)
        cb_est = ctk.CTkComboBox(f1, values=["Pendiente", "Aprobada", "Completada", "Cancelada"], width=130); cb_est.pack(side="left", padx=5)

        def mod_est():
            if txt_sol_id.get():
                cambiar_estado_solicitud(int(txt_sol_id.get()), cb_est.get())
                messagebox.showinfo("Éxito", "Estado actualizado.")

        ctk.CTkButton(f1, text="Actualizar", command=mod_est).pack(side="left", padx=5)

        f2 = ctk.CTkFrame(frame); f2.pack(fill="x", pady=10, padx=10)
        ctk.CTkLabel(f2, text="Eliminar Empleado:").pack(side="left", padx=5)
        txt_emp_id = ctk.CTkEntry(f2, placeholder_text="ID Empleado", width=100); txt_emp_id.pack(side="left", padx=5)

        def del_emp():
            if txt_emp_id.get():
                res = eliminar_empleado(int(txt_emp_id.get()))
                messagebox.showinfo("Resultado", res)

        ctk.CTkButton(f2, text="Eliminar", command=del_emp, fg_color="red").pack(side="left", padx=5)

if __name__ == "__main__":
    app = AppEscritorio()
    app.mainloop()