import pyodbc

def obtener_conexion():
    try:
        
        conexion = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=.\\SQLEXPRESS;'
            'DATABASE=GestionAudiovisual;'
            'Trusted_Connection=yes;'
        )
        return conexion
    except Exception as e:
        print(f"Error de conexión a SQL Server: {e}")
        return None